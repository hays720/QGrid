<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataGrid extends Model
{
    protected $table = 'DataGrid';
}
