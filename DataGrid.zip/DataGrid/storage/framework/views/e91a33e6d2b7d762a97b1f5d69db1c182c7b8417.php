<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script src="<?php echo e(asset('/Datagrid/ajax.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('/Datagrid/styless.css')); ?>">
</head>
<body>
<h1>Table 1</h1>
<table class="data-table">
    <caption class="title">Change Datagrid:</caption>
    <thead>
    <tr>
        <th><a id="no" href="?sort=NO">SNUM</a></th>
        <th> <a id="customer" href="?sort=CUSTOMER">CUSTOMER</a></th>
        <th> <a id="item" href="?sort=ITEM">ITEM</a></th>
        <th> <a id="amount" href="?sort=AMOUND">AMOUNT</a></th>
    </tr>
    </thead>
    <tbody>

    <?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($value->id); ?></td>
                <td><?php echo e($value->name); ?></td>
                <td><?php echo e($value->item); ?></td>
                <td><?php echo e($value->amount); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<form id="ajax_form" method="post">
    <?php echo e(csrf_field()); ?>

    <div class="form-row">
        <div class="col-3 ">
            <h2>If you wanna add:</h2>
        </div>
        <div class="col">
            <input type="text" name="customer" class="form-control" placeholder="CUSTOMER" required>
        </div>
        <div class="col">
            <input type="text" name="item" class="form-control" placeholder="ITEM" required>
        </div>
        <div class="col">
            <input type="number" name="amount" class="form-control" placeholder="AMOUNT" required>
        </div>

        <input type="button" id="btn" value="Send" />


    </div>
</form>

<form id="ajax_form_change" method="post">
    <div class="form-row">
        <div class="col-3 ">
            <h2>If you wanna edit:</h2>
        </div>
        <div class="col">
            <select name="ChoseEdit" class="form-control" id="exampleFormControlSelect2">
                <option disabled selected>Chose CUSTOMER</option>
                <?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($value->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        </div>
        <div class="col">
            <input type="text" name="ChangeCustomer" class="form-control" placeholder="NEW CUSTOMER" required>
        </div>
        <div class="col">
            <input type="text" name="ChangeItem" class="form-control" placeholder="ITEM" required>
        </div>
        <div class="col">
            <input type="number" name="ChangeAmount" class="form-control" placeholder="AMOUNT" required>
        </div>

        <input type="button" id="UpBtn" value="Send" />
        <?php echo e(csrf_field()); ?>

    </div>
</form>

<form id="ajax_delete_form" method="post">
    <div class="form-row">
        <div class="col-3 ">
            <h2>If you wanna delete:</h2>
        </div>
        <div class="col">
            <select name="ChoseDelete" class="form-control" id="exampleFormControlSelect3">
                <option disabled selected>Chose CUSTOMER</option>
                <?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($value->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col">
            <select name="ChoseDeleteItem" class="form-control" id="exampleFormControlSelect3">
                <option disabled selected>Chose ITEM</option>
                <<?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($value->item); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        </div>
        <input type="button" id="DeleteBtn" value="Send" />
        <?php echo e(csrf_field()); ?>

    </div>
</form>




</body>
</html>